﻿using System;

namespace Ordering.Domain
{
    public class Class1
    {
    }
}
