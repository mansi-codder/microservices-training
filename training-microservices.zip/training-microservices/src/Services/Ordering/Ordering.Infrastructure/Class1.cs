﻿using System;

namespace Ordering.Infrastructure
{
    public class Class1
    {
    }
}
