﻿using System;

namespace Ordering.Application
{
    public class Class1
    {
    }
}
